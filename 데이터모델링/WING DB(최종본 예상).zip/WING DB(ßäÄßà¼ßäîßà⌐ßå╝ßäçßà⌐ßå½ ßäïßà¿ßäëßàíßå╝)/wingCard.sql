--3번

DROP TABLE CARD;
DROP SEQUENCE CARD_NO_SEQ;

CREATE TABLE CARD(
    CARD_NO NUMBER DEFAULT 0 PRIMARY KEY,
    CARD_NAME VARCHAR2(100) DEFAULT '',
    CARD_COMPANY VARCHAR2(100) DEFAULT '',
    CATEGORY_NO NUMBER DEFAULT 0,
    CONSTRAINT MINUS_CATEGORY_NO_FK_ FOREIGN KEY(CATEGORY_NO) REFERENCES MINUS_CATEGORY (CATEGORY_NO),
    STORED_FILE_NAME VARCHAR2(200) DEFAULT '',
    ORIGINAL_FILE_NAME VARCHAR2(200) DEFAULT '',
    SUMMATION_BENEFIT VARCHAR2(1000) DEFAULT '',
    MAIN_BENEFIT VARCHAR2(500) DEFAULT '',
    REGISTER_DATE DATE DEFAULT SYSDATE
);

CREATE SEQUENCE CARD_NO_SEQ
    START WITH 1
    INCREMENT BY 1;
    
COMMENT ON TABLE CARD IS '카드';
COMMENT ON COLUMN CARD.CARD_NO IS '카드 번호';
COMMENT ON COLUMN CARD.CARD_NAME IS '카드명';
COMMENT ON COLUMN CARD.CARD_COMPANY IS '카드사';
COMMENT ON COLUMN CARD.CATEGORY_NO IS '카테고리 번호';
COMMENT ON COLUMN CARD.STORED_FILE_NAME IS '카드 이미지 실제 경로';
COMMENT ON COLUMN CARD.ORIGINAL_FILE_NAME IS '카드 이미지 이름';
COMMENT ON COLUMN CARD.SUMMATION_BENEFIT IS '혜택 요약';
COMMENT ON COLUMN CARD.MAIN_BENEFIT IS '주요 혜택';
COMMENT ON COLUMN CARD.REGISTER_DATE IS '카드 등록 날짜';

-- ^*^항공사, 기차, 고속버스 대중교통 10% 교통할인^*^국내외 가맹점 5% 쇼핑 할인^*^국내 가맹점 5% 식비 할인

desc card;

INSERT INTO CARD (CARD_NO, CARD_NAME, CARD_COMPANY, CATEGORY_NO, SUMMATION_BENEFIT, MAIN_BENEFIT)
VALUES(CARD_NO_SEQ.NEXTVAL, 'WING Traffic', 'WING', 3
    , '^*^항공사, 기차, 고속버스 대중교통 10% 교통할인^*^국내외 가맹점 5% 쇼핑 할인^*^국내 가맹점 5% 식비 할인'
    , '^*^교통할인-항공사, 기차, 고속버스, 대중교통-10%^*^쇼핑할인-국내외 가맹점-5%^*^식비할인-국내 가맹점-5%^*^생활할인-국내외 가맹점-5%'
);

INSERT INTO CARD (CARD_NO, CARD_NAME, CARD_COMPANY, CATEGORY_NO, SUMMATION_BENEFIT, MAIN_BENEFIT)
VALUES(CARD_NO_SEQ.NEXTVAL, 'WING Shopping', 'WING', 4
    , '^*^국내외 가맹점 10% 쇼핑 할인^*^항공사, 기차, 고속버스 대중교통 5% 교통할인^*^국내 가맹점 5% 식비 할인'
    , '^*^쇼핑할인-국내외 가맹점-10%^*^교통할인-항공사, 기차, 고속버스, 대중교통-5%^*^식비할인-국내 가맹점-5%^*^생활할인-국내외 가맹점-5%'
);

SELECT *
FROM CARD;

select *
from card c, selling_card sc, minus_category mc
where c.category_no = mc.CATEGORY_NO
and c.card_no = sc.card_no;

COMMIT;