$("#goBackPage").click((e) => {
  e.preventDefault();

  window.history.back();
})