export function playScroll() {
  $("body").removeClass("fixed");
}

export function stopScroll() {
  $("body").addClass("fixed");
}
