package com.edu.wing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WingSpringBootApplication {

  public static void main(String[] args) {

    SpringApplication.run(WingSpringBootApplication.class, args);
    System.out.println("@@@@@@@@@@========스타또========@@@@@@@@@@");

  }

}
