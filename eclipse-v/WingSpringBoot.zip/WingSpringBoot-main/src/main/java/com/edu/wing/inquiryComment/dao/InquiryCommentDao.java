package com.edu.wing.inquiryComment.dao;

import java.util.Map;

public interface InquiryCommentDao {

  int updateInquiryComment(int inquiryCommentNo, String content);

}
