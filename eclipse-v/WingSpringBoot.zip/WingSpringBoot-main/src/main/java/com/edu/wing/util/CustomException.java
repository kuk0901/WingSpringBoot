package com.edu.wing.util;

public class CustomException extends RuntimeException {
  public CustomException(String message) {
    super(message);
  }
}
