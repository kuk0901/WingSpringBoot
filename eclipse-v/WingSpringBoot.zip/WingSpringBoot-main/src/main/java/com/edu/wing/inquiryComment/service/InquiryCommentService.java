package com.edu.wing.inquiryComment.service;

public interface InquiryCommentService {

  boolean updateInquiryComment(int inquiryCommentNo, String content);

}
