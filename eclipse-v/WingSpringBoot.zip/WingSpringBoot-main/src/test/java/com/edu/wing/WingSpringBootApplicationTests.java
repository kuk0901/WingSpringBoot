package com.edu.wing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WingSpringBootApplicationTests {

  @Test
  void contextLoads() {
  }

}
